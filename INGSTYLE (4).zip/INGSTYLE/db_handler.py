"""Операции с базой данных SQLite."""

import sqlite3
from datetime import date, timedelta
from pathlib import Path

DB_PATH = Path(__file__).parent / "tracker.db"
SCHEMA_PATH = Path(__file__).parent / "schema.sql"


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with get_connection() as conn:
        conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
        conn.commit()


def today_str() -> str:
    return date.today().isoformat()


def has_record_today(user_id: int) -> bool:
    with get_connection() as conn:
        return conn.execute(
            "SELECT 1 FROM daily_records WHERE user_id = ? AND date = ?",
            (user_id, today_str()),
        ).fetchone() is not None


def add_record(
    user_id: int,
    mood: int,
    work_hours: float,
    sleep_hours: float,
    comment: str | None = None,
    record_date: str | None = None,
) -> bool:
    record_date = record_date or today_str()
    try:
        with get_connection() as conn:
            conn.execute(
                "INSERT INTO daily_records (user_id, date, mood, work_hours, sleep_hours, comment) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (user_id, record_date, mood, work_hours, sleep_hours, comment),
            )
            conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False


def get_records_between(user_id: int, start_date: str, end_date: str) -> list[sqlite3.Row]:
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM daily_records WHERE user_id = ? AND date >= ? AND date <= ? "
            "ORDER BY date ASC",
            (user_id, start_date, end_date),
        ).fetchall()


def get_last_records(user_id: int, limit: int = 7) -> list[sqlite3.Row]:
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM daily_records WHERE user_id = ? ORDER BY date DESC LIMIT ?",
            (user_id, limit),
        ).fetchall()


def delete_user_records(user_id: int) -> int:
    with get_connection() as conn:
        cur = conn.execute("DELETE FROM daily_records WHERE user_id = ?", (user_id,))
        conn.commit()
        return cur.rowcount


def get_reminder_time(user_id: int) -> str | None:
    with get_connection() as conn:
        row = conn.execute(
            "SELECT reminder_time FROM user_settings WHERE user_id = ?", (user_id,)
        ).fetchone()
    return row["reminder_time"] if row else None


def set_reminder_time(user_id: int, reminder_time: str) -> None:
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO user_settings (user_id, reminder_time) VALUES (?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET reminder_time = excluded.reminder_time",
            (user_id, reminder_time),
        )
        conn.commit()


def get_all_reminder_settings() -> list[tuple[int, str]]:
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT user_id, reminder_time FROM user_settings WHERE reminder_time IS NOT NULL"
        ).fetchall()
    return [(r["user_id"], r["reminder_time"]) for r in rows]


def period_dates(days: int) -> tuple[str, str]:
    end = date.today()
    return (end - timedelta(days=days - 1)).isoformat(), end.isoformat()


if __name__ == "__main__":
    init_db()
    print(f"База данных инициализирована: {DB_PATH}")
